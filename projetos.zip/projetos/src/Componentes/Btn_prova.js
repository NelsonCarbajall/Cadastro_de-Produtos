import React from "react";

const Btn_prova = (props) => {
    return(
        <button onClick={props.onClick}>{props.nome}</button>
    )
}

export default Btn_prova;