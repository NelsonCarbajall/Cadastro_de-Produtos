import react from 'react';

const MeuComponente = (props) => {

    return(
        <button>{props.conteudo_}</button>
    );
}

export default MeuComponente;