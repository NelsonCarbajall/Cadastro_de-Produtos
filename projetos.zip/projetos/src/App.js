import React, { Component, useState } from 'react';
import './App.css'

function App() {

    const[nome_, setNome] = useState("");
    const[ano_, setAno] = useState("");
    const[email_, setEmail] = useState("");

    const[state1, setstate1] = useState("");
    const[state2, setstate2] = useState("");
    const[state3, setstate3] = useState("");

      const handleName = (event) => {
        setNome(event.target.value)
      }
      const handleAno = (event) => {
        setAno(event.target.value)
      }
      const handleEmail = (event) => {
        setEmail(event.target.value)
      }

      function Enviar(){
        setstate1("Seu nome é: " + nome_);
        setstate2("Sua idade é: " + (2024 - parseInt(ano_)).toString());
        setstate3("Seu email é: " + email_);
      }
      
    return (
      <div className='App'>
        <div className='Container'>
        <label>Insira seu nome:</label> 
        <input value={nome_} onChange={handleName}></input>
        <br></br>
        <label>Insira seu ano de nascimento:</label> 
        <input value={ano_} onChange={handleAno}></input>
        <br></br>
        <label>Insira seu email:</label>
        <input value={email_} onChange={handleEmail}></input>
       <br></br>
        <button onClick={() => Enviar()}>Enviar!</button>
       
        </div>

        {state1} <br></br>
        {state2} <br></br>
        {state3} <br></br>


      </div>
    );
  
}

export default App;


/*
import React, { Component } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './Componentes/Home';
import About from './Componentes/About';
import Contact from './Componentes/Contact';

class App extends Component {
  render() {
    return (
    <Router>
        <div>
          <h2>Welcome to React Router Tutorial</h2>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <ul className="navbar-nav mr-auto">
            <li><Link to={'/'} className="nav-link"> Home </Link></li>
            <li><Link to={'/contact'} className="nav-link">Contact</Link></li>
            <li><Link to={'/about'} className="nav-link">About</Link></li>
          </ul>
          </nav>
          <hr />
          <Routes>
              <Route path='/' element={<Home/> } />
              <Route path='/contact'  element={<Contact/> } />
              <Route path='/about'  element={<About/> } />
          </Routes>
        </div>
      </Router>
    );
  }
}

export default App;
*/